import React, { Component, useState } from 'react';
import isElectron from '../library/isElectron';
import { Redirect, Link } from "react-router-dom";
import MidiTrack from '../components/MidiTrack/index'
import logo from '../images/logo_dev.png'
import Sidebar from '../components/Sidebar/index'
import axios from 'axios';
import 'html-midi-player'
import { PlayerElement } from 'html-midi-player';
class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "React",
      showMenu: false,
      username: '',
      password: '',
      email: '',
      redirect: null,
      electron: null,
      currentTrack: '',
      currentKey: '',
      currentScale: '',
      currentBPM: '',
      rawMidiString: '',
      playing: false,
      loggedin: 0,
      myMidis: [],
      loadedMidis: false,
      noMidis: true
    };
    this.onDownloadMIDI = this.onDownloadMIDI.bind(this);
    this.startPlay = this.startPlay.bind(this);
    this.stopPlay = this.stopPlay.bind(this);
    this.resumePlay = this.resumePlay.bind(this);
  }

  onStartPlaying = (id, name, key, scale, bpm, midiData) => {
    console.log("playing");
    console.log(id);
    console.log(name);
    this.setState({ currentTrack: name, 
                    currentKey: key,
                    currentScale: scale, 
                    currentBPM: bpm, 
                    playing: true , 
                    rawMidiString: 'data:audio/midi;base64,' + midiData})
    
    setTimeout(
      function () {
        this.startPlay();
      }.bind(this),1000);
  }

  onStopPlaying = () => {

    this.setState({ playing: false })
  this.stopPlay();
  }
  onResumePlaying = () => {
    this.setState({ playing: true })
    this.resumePlay();
  }

  startPlay() {
    var player = document.querySelector("midi-player");
    player.start();
    console.log("STARTPLAY");
    console.log(player);
    console.log(document.querySelector("midi-player"));
  }
  stopPlay(){
    var player = document.querySelector("midi-player");
    player.stop();
    console.log("STOPPLAY");

  }
  resumePlay(){
    var player = document.querySelector("midi-player");
    player.start();
    console.log("RESUMEPLAY");

  }
  onLogout = (e) => {
    //e.preventDefault();
    localStorage.clear();
    this.setState({
      username: '',
      password: '',
      email: '',
    });

    if (isElectron()) {
      this.setState({ loggedin: 0 });
    } else {
      this.setState({ loggedin: 1 });
    }

    if (isElectron()) {
      this.setState({ redirect: "/music-generation" });
    } else {
      this.setState({ redirect: "/" });
    }
  }

  showMyMIDIS = (e) => {
    if (this.state.email && this.state.password) {
      const options = {
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        }
      };

      const midiObject = {
        email: this.state.email,
        password: this.state.password
      };

      axios.post('/api/midis/mine', midiObject, options)
        .then((res) => {
          if (res.status == 200) {
            console.log("Getting my MIDIS");
            console.log(res.data);
            if (res.data == [])
            {
              this.setState({ noMidis: true });
            }
            else
            {
              this.setState({ noMidis: false });
              
            }

            this.setState({ myMidis: res.data ,loadedMidis: true});
            console.log(this.state.myMidis[0]);
            console.log(this.state.myMidis[1]);
          }
        }).catch((error) => {
          console.log(error);
        });
    }
  }


  componentDidMount() {
    try {
      if (localStorage.getItem('username') !== null) {
        this.setState({
          username: localStorage.getItem('username'),
          email: localStorage.getItem('email'),
          password: localStorage.getItem('password'),
        })
      }
      console.log(localStorage.getItem('loggedIn'));
      if (localStorage.getItem('loggedIn') == true) {
        this.setState({ loggedin: 1 });
      }
      else {
        this.setState({ loggedin: 0 });
      }
    } catch (e) {
      this.setState({ loggedin: 0 });
      console.log(e);
    }
    var player = document.querySelector("midi-player");
  }

  // Download midi file
  onDownloadMIDI() {
    window.ipcRenderer.send('download_midi_file', this.state.rawMidiString);
  }




  render() {
    if (this.state.redirect) {
      return <Redirect to={{
        pathname: this.state.redirect,
        state: {
          username: this.state.username,
          email: this.state.email,
          password: this.state.password
        }
      }}
      />
    }

    if (this.state.electron == null) {
      if (isElectron()) {
        this.setState({
          electron: true
        });
      } else {
        this.setState({
          electron: false
        });
      }
    }

    if (localStorage.getItem('loggedIn') == 'true' && this.state.loggedin == 0) {
      this.setState({ loggedin: 1 });
    }
    if (!this.state.loadedMidis)
      this.showMyMIDIS();
    
    return (
      <div class="music-generation-bg" style={{ margin: '0' }}>
        <Sidebar
          active="dashboard"
          is_shown="true"
          logout={this.onLogout}
          logged_in={this.state.loggedin}
          username={this.state.username}
          email={this.state.email}
          password={this.state.password}
        ></Sidebar>
         <script src="https://cdn.jsdelivr.net/combine/npm/tone@14.7.58,npm/@magenta/music@1.22.1/es6/core.js,npm/focus-visible@5,npm/html-midi-player@1.4.0"></script>

        <midi-player style={{ display: 'none' }} src={this.state.rawMidiString} ></midi-player>
        <div id="main_content">
          <h2>My MIDI</h2>
          <div class="midi-add" style={{ display: isElectron() ? 'inline-block' : 'none' }}><Link to={{ pathname: "/music-generation", state: { username: this.state.username, email: this.state.email, password: this.state.password } }}><i class="material-icons">add</i> Add Track</Link></div>
          <div id="midi-tracks1" style={{ marginTop: '10px' }}>
            {this.state.noMidis ? '': this.state.myMidis.map(listitem => (
              <MidiTrack playfn={this.onStartPlaying} midiData={listitem.midiData} track_id={listitem._id} track_name={listitem.name} isowner={1} privacy={listitem.privacy} link={listitem.link} song_key={listitem.key} scale={listitem.scale} bpm={listitem.bpm}></MidiTrack>
            ))}
          </div>
        </div>

        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />





        <div id="stream-bar">
          <div class="column" style={{ width: '10%' }}>
            <   div id="play_stream" style={{ display: this.state.saveOptions ? 'none' : 'block' }}>
              <i class="material-icons" onClick={this.onResumePlaying} style={{ display: this.state.playing ? 'none' : 'inline-block', fontSize: '59px' }}>play_circle_filled</i>
              <i class="material-icons" onClick={this.onStopPlaying} style={{ display: this.state.playing ? 'inline-block' : 'none', fontSize: '59px' }}>pause</i>

            </div>

          </div>
          <div class="column" style={{ width: '80%' }}>
            <h3 style={{ marginBottom: '0px' }} >{this.state.currentTrack}</h3>



            <table style={{ textAlign: 'center', display: 'inline-block' }}>
              <tr>
                <th>KEY</th>
                <th>SCALE</th>
                <th>BPM</th>

              </tr>
              <tr>
                <td>{this.state.currentKey}</td>
                <td>{this.state.currentScale}</td>
                <td>{this.state.currentBPM}</td>
              </tr>
            </table>

          </div>
          <div class="column" style={{ width: '10%' }}>

          </div>


        </div>
      </div>



    );
  }
}
export default Dashboard