window.ipcRenderer = require('electron').ipcRenderer;
