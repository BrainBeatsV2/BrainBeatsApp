# Installing Brain Beats Desktop: 
### 0) Install npm & nodejs: https://docs.npmjs.com/downloading-and-installing-node-js-and-npm
### 1) Unzip release.zip
### 2) Navigate to the unzipped folder
```
cd release
```
### 3) Install dependencies
```
npm install
```
### 4) Build the application
```
npm run build
```
### 5) Run the app!
```
npm run desktop
```
