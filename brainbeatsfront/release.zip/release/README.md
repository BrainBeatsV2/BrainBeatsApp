# Installing Brain Beats Desktop: 
### 0) Install npm & nodejs: https://docs.npmjs.com/downloading-and-installing-node-js-and-npm
### 0) Install Python: https://www.python.org/downloads/
### 1) Unzip release.zip - https://github.com/BrainBeatsV2/BrainBeatsApp/raw/dev/brainbeatsfront/release.zip
### 2) Navigate to the unzipped folder
```
cd release
```
### 3) Install dependencies
```
npm install
```
### 4) Run the app!
```
npm run desktop
```
